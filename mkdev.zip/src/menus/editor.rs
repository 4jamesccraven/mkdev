// mkdev - Save your boilerplate instead of writing it
// Copyright (C) 2026  James C. Craven <4jamesccraven@gmail.com>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//! An editor to modify an existing recipe.
use super::confirm_action;

use crate::cli::Edit;
use crate::config::Config;
use crate::content::RecipeItem;
use crate::mkdev_error::Error;
use crate::recipe::Recipe;

use std::collections::{HashMap, HashSet};
use std::path::PathBuf;

use colored::Colorize;
use inquire::error::InquireResult;
use inquire::formatter::MultiOptionFormatter;
use inquire::validator::{Validation, ValueRequiredValidator};
use inquire::{Editor, MultiSelect, Select, Text};
use rust_i18n::t;
use strum::IntoEnumIterator;

/// Invoke an editor that continuously allows inspection and editing of various data within the
/// recipe.
///
/// On exit, the user may choose to save the recipe, at which point it is canonicalised and then
/// saved to the recipe directory.
pub fn editor(args: Edit, user_recipes: HashMap<String, Recipe>) -> Result<(), Error> {
    // Ensure the config is loaded in memory before proceeding.
    let _config = Config::get()?;
    let mut recipe = Recipe::pick(&user_recipes, &args.recipe)?.clone();
    let mut recipe_altered = false;

    loop {
        // Target field/action,
        let action = EditorAction::select_action()?;

        // Handle quitting.
        if let EditorAction::Quit = action {
            if EditorAction::quit_menu(recipe_altered)? {
                break;
            } else {
                continue;
            }
        }

        // Try to dispatch an edit. If it succeeds and a change is made, update `recipe_altered`
        // and print a newline for readability.
        recipe_altered |= action.dispatch(&mut recipe)?;
        println!();
    }

    Ok(())
}

/// Actions that the editor can take
#[derive(Clone, Copy, Debug, strum::EnumIter)]
enum EditorAction {
    Name,
    Description,
    AddContent,
    EditContent,
    RemoveContents,
    Quit,
}

impl EditorAction {
    /// Selects the next action the editor should take.
    fn select_action() -> InquireResult<EditorAction> {
        let message = &t!("menus.editor.what_next");
        let opts: Vec<_> = EditorAction::iter().collect();
        let vim = Config::get().unwrap().vim;

        Select::new(message, opts)
            .with_vim_mode(vim)
            .with_help_message(&t!("menus.select_help"))
            .prompt()
    }

    /// Inspect the field if applicable, then run the edit dialogue.
    ///
    /// Returns `Ok(true)` if an edit has been made.
    pub fn dispatch(&self, recipe: &mut Recipe) -> InquireResult<bool> {
        self.inspect(recipe);
        self.edit(recipe)
    }

    /// Dispatcher for the different fields that can be edited.
    ///
    /// Returns `Ok(true)` if an edit has been made.
    fn edit(&self, recipe: &mut Recipe) -> InquireResult<bool> {
        match self {
            Self::AddContent => self.add_content(recipe),
            Self::Description => self.edit_description(recipe),
            Self::EditContent => self.edit_content(recipe),
            Self::Name => self.edit_name(recipe),
            Self::RemoveContents => self.remove_contents(recipe),
            Self::Quit => unreachable!(),
        }
    }

    fn edit_name(&self, recipe: &mut Recipe) -> InquireResult<bool> {
        if !Self::confirm_edit()? {
            return Ok(false);
        }

        let prompt = Text::new(&t!("menus.imprint.get_name"))
            .with_validator(ValueRequiredValidator::new(t!(
                "menus.imprint.name_required"
            )))
            .prompt_skippable()?;

        let Some(name) = prompt else {
            return Ok(false);
        };

        recipe.name = name;
        Ok(true)
    }

    fn edit_description(&self, recipe: &mut Recipe) -> InquireResult<bool> {
        if !Self::confirm_edit()? {
            return Ok(false);
        }

        let prompt = Text::new(&t!("menus.imprint.get_desc")).prompt_skippable()?;

        let Some(desc) = prompt else {
            return Ok(false);
        };

        recipe.description = desc;
        Ok(true)
    }

    fn add_content(&self, recipe: &mut Recipe) -> InquireResult<bool> {
        let prompt = Text::new(&t!("menus.editor.get_content_name"))
            .with_validator(ValueRequiredValidator::new(t!(
                "menus.editor.content_name_required"
            )))
            .with_validator(|i: &str| {
                if recipe.contents.iter().any(|item| item.name() == i) {
                    Ok(Validation::Invalid(
                        t!("menus.editor.invalid_content_name").into(),
                    ))
                } else {
                    Ok(Validation::Valid)
                }
            })
            .prompt_skippable()?;

        let Some(name) = prompt else {
            return Ok(false);
        };

        let path = PathBuf::from(name);

        let prompt = Select::new(&t!(""), ContentType::iter().collect()).prompt_skippable()?;
        let Some(typ) = prompt else {
            return Ok(false);
        };

        match typ {
            ContentType::Directory => {
                recipe.contents.push(RecipeItem::Directory(path));
                Ok(true)
            }
            ContentType::File => {
                let extension = path
                    .extension()
                    .unwrap_or_default()
                    .to_str()
                    .unwrap_or_default();

                let prompt = Editor::new(&t!("menus.editor.get_item_contents"))
                    .with_file_extension(&format!(".{extension}"))
                    .prompt_skippable()?;

                let Some(contents) = prompt else {
                    return Ok(false);
                };

                recipe.contents.push(RecipeItem::File(crate::content::File {
                    name: path,
                    content: contents,
                }));

                Ok(true)
            }
        }
    }

    fn edit_content(&self, recipe: &mut Recipe) -> InquireResult<bool> {
        let vim = Config::get()
            .expect("The config should be loaded at the top of a menu")
            .vim;

        let prompt = Select::new(&t!("menus.imprint.filter_rec"), recipe.contents.clone())
            .with_help_message(&t!("menus.select_help"))
            .with_vim_mode(vim)
            .prompt_skippable()?;

        let Some(content_item) = prompt else {
            return Ok(false);
        };

        let msg = &t!("menus.editor.get_content_name");
        let prompt = Text::new(msg)
            .with_validator(ValueRequiredValidator::new(t!(
                "menus.editor.content_name_required"
            )))
            .with_validator(|i: &str| {
                if i == content_item.name() {
                    Ok(Validation::Valid)
                } else if recipe.contents.iter().any(|item| item.name() == i) {
                    Ok(Validation::Invalid(
                        t!("menus.editor.invalid_content_name").into(),
                    ))
                } else {
                    Ok(Validation::Valid)
                }
            });

        match content_item {
            RecipeItem::Directory(ref p) => {
                let prompt = prompt
                    .with_initial_value(p.to_str().unwrap_or_default())
                    .prompt_skippable()?;

                let Some(name) = prompt else {
                    return Ok(false);
                };
                let path = PathBuf::from(name);

                match recipe.contents.iter_mut().find(|item| *item.name() == *p) {
                    Some(item) => {
                        *item = RecipeItem::Directory(path);
                        Ok(true)
                    }
                    None => Ok(false),
                }
            }
            RecipeItem::File(ref f) => {
                let prompt = prompt
                    .with_initial_value(f.name.to_str().unwrap_or_default())
                    .prompt_skippable()?;

                let Some(name) = prompt else {
                    return Ok(false);
                };
                let path = PathBuf::from(name);
                let extension = path
                    .extension()
                    .unwrap_or_default()
                    .to_str()
                    .unwrap_or_default();

                let prompt = Editor::new(&t!("menus.editor.get_item_contents"))
                    .with_file_extension(&format!(".{extension}"))
                    .with_predefined_text(&f.content)
                    .prompt_skippable()?;
                let Some(content) = prompt else {
                    return Ok(false);
                };

                match recipe
                    .contents
                    .iter_mut()
                    .find(|item| *item.name() == f.name)
                {
                    Some(item) => {
                        *item = RecipeItem::File(crate::content::File {
                            name: path,
                            content,
                        });
                        Ok(true)
                    }
                    None => Ok(false),
                }
            }
        }
    }

    fn remove_contents(&self, recipe: &mut Recipe) -> InquireResult<bool> {
        let formatter: MultiOptionFormatter<RecipeItem> = &super::multiselect_truncate_formatter;
        let vim = Config::get()
            .expect("The config should be loaded at the top of a menu")
            .vim;

        let prompt = MultiSelect::new(&t!("menus.imprint.filter_rec"), recipe.contents.clone())
            .with_formatter(formatter)
            .with_help_message(&t!("menus.multiselect_help"))
            .with_vim_mode(vim)
            .prompt_skippable()?;

        let Some(contents) = prompt else {
            return Ok(false);
        };

        let lookup: HashSet<_> = contents.into_iter().collect();
        recipe.contents.retain(|r| !lookup.contains(r));
        Ok(true)
    }

    /// Present the current value of the given field if applicable, do nothing otherwise.
    fn inspect(&self, recipe: &Recipe) {
        let val = match self {
            Self::Name => format!("\"{}\"", recipe.name),
            Self::Description => format!("\"{}\"", recipe.description),
            Self::AddContent | Self::RemoveContents | Self::EditContent => recipe
                .display_contents()
                .lines()
                .collect::<Vec<_>>()
                .join("\n  "),
            _ => return,
        };

        println!(
            "{} {}:\n  {}",
            ">".green(),
            t!("menus.editor.curr_val"),
            val
        )
    }

    /// Confirm that the user wants to edit before proceeding.
    fn confirm_edit() -> InquireResult<bool> {
        confirm_action(&t!("menus.editor.want_edit"), false)
    }

    /// Handles exiting the editor.
    ///
    /// If the editor should close, `Ok(true)` is returned. `altered` informs whether or not a recipe has
    /// been altered. If it hasn't the editor simply closes. If the recipe has been altered, the user
    /// is presented with the choice to save and exit, exit without saving, or cancel (not exit).
    fn quit_menu(altered: bool) -> InquireResult<bool> {
        if !altered {
            Ok(true)
        } else {
            let opts = ExitAction::iter().collect();
            let prompt = Select::new(&t!("menus.editor.save"), opts).prompt_skippable()?;

            let Some(choice) = prompt else {
                return Ok(false);
            };

            match choice {
                ExitAction::Save => todo!(),
                ExitAction::Exit => Ok(true),
                ExitAction::Cancel => Ok(false),
            }
        }
    }
}

impl std::fmt::Display for EditorAction {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "{}",
            match self {
                Self::AddContent => t!("editor.actions.add_content"),
                Self::Description => t!("editor.actions.description"),
                Self::EditContent => t!("editor.actions.edit_content"),
                Self::Name => t!("editor.actions.name"),
                Self::Quit => t!("general.quit"),
                Self::RemoveContents => t!("editor.actions.remove_contents"),
            }
        )
    }
}

/// Strategy enum that dictates what happens when a user tries to exit with unsaved changes.
#[derive(Clone, Copy, Debug, strum::EnumIter)]
enum ExitAction {
    Save,
    Exit,
    Cancel,
}

impl std::fmt::Display for ExitAction {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "{}",
            match self {
                Self::Save => t!("editor.exit.save"),
                Self::Exit => t!("editor.exit.exit"),
                Self::Cancel => t!("editor.exit.cancel"),
            }
        )
    }
}

#[derive(Clone, Copy, Debug, strum::EnumIter)]
enum ContentType {
    File,
    Directory,
}

impl std::fmt::Display for ContentType {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "{}",
            match self {
                Self::File => t!("general.file"),
                Self::Directory => t!("general.directory"),
            }
        )
    }
}
