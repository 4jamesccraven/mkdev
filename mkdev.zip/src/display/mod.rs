// mkdev - Save your boilerplate instead of writing it
// Copyright (C) 2026  James C. Craven <4jamesccraven@gmail.com>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//! User-facing display for recipes.
mod display_config;
mod tree;

pub use display_config::DisplayConfig;
pub use tree::repr_tree;

use crate::recipe::{Language, Recipe};
use crate::replacer::{InvalidTokenStrategy, ReplaceFmt};

use std::collections::HashMap;

use colored::Colorize;

const DELIMS: (&str, &str) = ("{", "}");
const FALLBACK: InvalidTokenStrategy = InvalidTokenStrategy::Preserve;

/// Formats and displays a list of recipes according to a provided configuration.
pub fn display_recipes_with_config(recipes: &[&Recipe], config: &DisplayConfig) -> String {
    recipes
        .iter()
        .map(|r| cfg_display_recipe(r, config))
        .collect::<Vec<String>>()
        .join(&config.recipes_join)
        + config.recipes_suffix.as_str()
}

/// Formats a single recipe according to a provided configuration.
fn cfg_display_recipe(recipe: &Recipe, config: &DisplayConfig) -> String {
    let show_description = config.show_descriptions.unwrap_or(true);

    let subs = HashMap::from([
        (
            "name".to_string(),
            cfg_display_recipe_name(&recipe.name, &config.name_fmt, config.name_bold),
        ),
        (
            "langs".to_string(),
            cfg_display_langs(
                &recipe.languages,
                &config.lang_fmt,
                &config.langs_join,
                config.lang_colour,
            ),
        ),
        (
            "desc".to_string(),
            cfg_display_description(&recipe.description, &config.desc_fmt, show_description),
        ),
    ]);

    replace(subs, &config.recipe_fmt)
}

/// Helper function to fill a format string.
#[inline(always)]
fn replace(subs: HashMap<String, String>, fmt_string: &str) -> String {
    ReplaceFmt::new(subs, DELIMS, FALLBACK).replace(fmt_string)
}

/// Displays the recipe name as configured.
fn cfg_display_recipe_name(name: &str, fmt_string: &str, bold: bool) -> String {
    let name_fmt = if bold {
        name.to_string().bold().to_string()
    } else {
        name.to_string()
    };

    let subs = HashMap::from([("name".to_string(), name_fmt)]);
    replace(subs, fmt_string)
}

/// Displays the recipe languages as configured.
fn cfg_display_langs(
    langs: &[Language],
    fmt_string: &str,
    join_string: &str,
    show_colour: bool,
) -> String {
    langs
        .iter()
        .map(|l| {
            HashMap::from([(
                "lang".to_string(),
                if show_colour {
                    format!("{l}")
                } else {
                    l.name.clone()
                },
            )])
        })
        .map(|subs| replace(subs, fmt_string))
        .collect::<Vec<String>>()
        .join(join_string)
}

/// Displays the recipe description as configured.
fn cfg_display_description(description: &str, fmt_string: &str, show_desc: bool) -> String {
    if !show_desc {
        return "".into();
    }

    let subs = HashMap::from([("desc".to_string(), description.to_string())]);
    replace(subs, fmt_string)
}
